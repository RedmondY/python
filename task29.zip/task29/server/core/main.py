from core.user_handle import UserHandle
from core.server import FTPServer
from lib import common

logger=common.get_logger(__name__)

class Manager():
    def __init__(self):
        pass

    def start_ftp(self):
        server = FTPServer()
        server.run()
        server.close()

    def create_user(self):
        username = input('username>>>:').strip()
        UserHandle(username).add_user()

    def quit_func(self):
        quit('bye bye ...')

    def run(self):
        msg = '''
        1.启动ftp服务器
        2.创建用户
        3.退出\n
        '''
        msg_dic = {'1': 'start_ftp', '2': 'create_user', '3': 'quit_func'}
        while True:
            print(msg)
            num = input('num>>>:').strip()
            

            if num in msg_dic:
                if num == '1':
                    logger.info('启动服务器')
                elif num == '2':
                    logger.info('创建用户')
                elif num == '3':
                    logger.info('退出')
                else:
                    logger.warning('输入错误字符')
                getattr(self,msg_dic[num])()
            else:
                print('请重新选择')
                logger.warning('输入错误字符')